var menu_visible = false;
let menu = document.getElementById("nav");
function mostrarOcultarMenu(){
    if(menu_visible == false)//si esta oculto que lo muestre
    {
        menu.style.display = "block";
        menu_visible = true;
    }
    else{
        menu.style.display = "none";
        menu_visible = false;
    }
}
//oculto las opciones del menu una vez que se haya hecho clik en algunas de las opciones
let links = document.querySelectorAll("nav a");
for(var x = 0; x < links.length;x++)
{
    links[x].onclick = function(){
        menu.style.display = "none";
        menu_visible = false;
    }
}
//creo las barritas de una barra particular identificada por su id
function crearBarra(id_barra){
    for(i=0;i<=16;i++){
        let div = document.createElement("div");
        div.className = "e";
        id_barra.appendChild(div);
    }
}

//selecciono todas las barras generales para luego manipularlas
let html = document.getElementById("html");
crearBarra(html);

let javascript = document.getElementById("javascript");
crearBarra(javascript);

let word = document.getElementById("word");
crearBarra(word);

let excel = document.getElementById("excel");
crearBarra(excel);

//Ahora se guardan la ctdad de barritas que se van a ir pintando por cada barra
//para eso utilizo un vector/arreglo, cada posicion pertenece a un elemento 
//comienzan en -1 porque no tiene ninguna pintada al iniciarse
let contadores = [-1,-1,-1,-1,-1,-1];
//creo una variable que la voy a utilizar como bandera para saber si ya ejecuto la animacion de las barras
let entro = false;
//funcion que aplica las animaciones de la seccion de habilidades
function efectoHabilidades(){
    var habilidades = document.getElementById("habilidades");
    var distancia_skills = window.innerHeight - habilidades.getBoundingClientRect().top;
    if(distancia_skills>=300 && entro==false){
        entro = true;
        const intervalHtml = setInterval(function(){
            pintarBarra(html, 16, 2, intervalHtml)
        },100)

        const intervalJavascript = setInterval(function(){
            pintarBarra(javascript, 11, 3, intervalJavascript)
        },100)

        const intervalExcel = setInterval(function(){
            pintarBarra(excel, 16, 1, intervalExcel)
        },100)

        const intervalWord = setInterval(function(){
            pintarBarra(word, 17, 0, intervalWord)
        },100)
    }
}

//lleno las barras con la cantidad generada
function pintarBarra(id_barra, cantidad, indice, interval){
    contadores[indice]++;
    x = contadores[indice];
    if(x < cantidad){
        let elementos = id_barra.getElementsByClassName("e");
        elementos[x].style.backgroundColor = "#940253";
    }else{
        clearInterval(interval)
    }
}
//detecto el scrolling del mouse para aplicar la animacion de la barra
window.onscroll = function(){
    efectoHabilidades();
}

